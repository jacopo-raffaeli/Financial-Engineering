%% ASSIGNMENT 7
%
% GROUP 14
%

clear;
clc;
close all;

%%
runES1

%%
runES2

